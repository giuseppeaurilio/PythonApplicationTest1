class Country:
    def __init__(self, id, regionids, totpopulation):
        self.id = id
        self.regionIds = []
        self.totPopulation = totpopulation